
class Agent:
    def __init__(self):
        pass

    def take_action(self,observation):
        raise NotImplementedError
