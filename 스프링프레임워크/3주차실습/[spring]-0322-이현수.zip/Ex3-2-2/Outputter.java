package Ex3_2_2;

import java.io.IOException;

public interface Outputter {
	void output(String message) throws IOException;
}
