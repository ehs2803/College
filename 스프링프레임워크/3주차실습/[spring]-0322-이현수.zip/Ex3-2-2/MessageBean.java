package Ex3_2_2;

public interface MessageBean {
	void sayHello();
}
