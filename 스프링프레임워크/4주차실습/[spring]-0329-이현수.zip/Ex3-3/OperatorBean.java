package Ex3_3;

public interface OperatorBean {
	double calc();
}
