package Ex4_2;

public class Operand {
	double value;
	
	public Operand(double value) {
		this.value=value;
	}
	
	public void setValue(int value) {
		this.value=value;
	}
	
	public double getValue() {
		return value;
	}
}
