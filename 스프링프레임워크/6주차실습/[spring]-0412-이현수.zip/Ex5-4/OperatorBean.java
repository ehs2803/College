package Ex4_2;

public interface OperatorBean {
	double calc();
	Operand getOperand1();
	void setOperand1(Operand op);
	Operand getOperand2();
	void setOperand2(Operand op);
}
