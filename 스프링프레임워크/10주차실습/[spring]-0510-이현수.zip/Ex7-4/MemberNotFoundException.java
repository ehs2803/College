package spring;

public class MemberNotFoundException extends RuntimeException {

}
