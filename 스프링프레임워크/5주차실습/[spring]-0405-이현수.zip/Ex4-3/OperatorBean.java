package Ex4_2;

public interface OperatorBean {
	double calc();
}
