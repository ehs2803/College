package skunic.cs.spring.ex11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
