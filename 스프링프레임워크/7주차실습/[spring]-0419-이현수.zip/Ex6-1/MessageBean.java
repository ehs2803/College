package Ex6_1;

public interface MessageBean {
	void sayHello();
}
